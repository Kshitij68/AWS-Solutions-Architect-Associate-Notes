#!/bin/sh

set -ex

pip-compile -v --upgrade --rebuild --index-url https://pypi.org/simple --output-file requirements-pinned.txt requirements.in
pip-compile -v --upgrade --rebuild --index-url https://pypi.org/simple --output-file test-requirements-pinned.txt requirements-pinned.txt test-requirements.in