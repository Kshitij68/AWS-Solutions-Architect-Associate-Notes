from typing import Dict


class Vehicle:
    def __init__(self, v_name: str, v_id: str):
        self._v_name = v_name
        self._v_id = v_id

    @property
    def name(self) -> str:
        return self._v_name

    def to_json(self) -> Dict[str, str]:
        return {
            "name": self._v_name,
            "id": self._v_id,
        }

    def __eq__(self, other) -> bool:
        return self.to_json()["id"] == other.to_json()["id"]
