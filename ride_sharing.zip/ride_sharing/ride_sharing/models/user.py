from typing import Dict, List

from ride_sharing.models.vehicle import Vehicle


class User:
    def __init__(self, name: str, age: int, gender: str):
        # TODO - Could be explored on the possibility of breaking down into `driver` and `rider`.
        # However, you will also have to take care of scenarios where someone is a rider as well as driver
        # things like updating info can be tricky
        self.__name = name
        self.__age = age
        self.__gender = gender
        self.__vehicles: List[Vehicle] = list()

    @property
    def vehicles(self) -> List:
        return self.__vehicles

    def get_name(self) -> str:
        return self.__name

    def set_age(self, age) -> None:
        self.__age = age

    def set_gender(self, gender) -> None:
        self.__gender = gender

    def to_json(self) -> Dict:
        return {
            "name": self.__name,
            "age": self.__age,
            "gender": self.__gender,
            "vehicle": [vehicle.to_json() for vehicle in self.__vehicles],
        }
