from typing import Dict, List

from ride_sharing.constants.constants import TripStatus
from ride_sharing.models.user import User
from ride_sharing.models.vehicle import Vehicle


class Trip:
    def __init__(
        self,
        driver: User,
        source: str,
        destination: str,
        available_seats: int,
        vehicle: Vehicle,
    ):
        self.__driver = driver
        self.__source = source
        self.__destination = destination
        self.__available_seats = available_seats
        self.__vehicle = vehicle
        self.__status = TripStatus.SCHEDULED.name
        self.riders: List[User] = list()

    @property
    def status(self) -> str:
        return self.__status

    @status.setter
    def status(self, value) -> None:
        self.__status = value

    @property
    def driver_name(self) -> str:
        return self.__driver.get_name()

    @property
    def source(self) -> str:
        return self.__source

    @property
    def destination(self) -> str:
        return self.__destination

    @property
    def available_seats(self) -> int:
        return self.__available_seats

    @available_seats.setter
    def available_seats(self, value) -> None:
        self.__available_seats = value

    def to_json(self) -> Dict:
        return {
            "name": self.__driver.get_name(),
            "vehicle": self.__vehicle.to_json(),
            "status": self.__status,
        }

    @property
    def vehicle(self):
        return self.__vehicle

    def __eq__(self, other):
        """
        Two trips are considered same if they belong to the same car
        """
        return self.__vehicle == other.__vehicle and self.status == other.status
