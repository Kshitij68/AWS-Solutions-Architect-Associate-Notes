from collections import deque
from typing import Dict, List

from ride_sharing.constants.constants import SelectionStrategies
from ride_sharing.models.trip import Trip, TripStatus


class RouteFindingManager:
    @staticmethod
    def find_ride_via_multiple_trips(
        user_name: str,
        source: str,
        destination: str,
        seats: int,
        selection_strategy: str,
        trips: Dict[str, List[Trip]],
        max_trips,
    ):
        """
        This algorithm is a BFS algorithm which tries to find the optimum path from source to destination
        while following the selection strategy

        # TODO - It might be possible to optimize the current algorithm,
        but tests must be carefully written to capture the edge cases

        # TODO - Explore breaking down into two classes based on strategies

        Parameters
        -------------
        user_name: str
            user name of person requesting the ride
        source: str`
            Start point of the person requesting the ride
        destination: str
            Destination point of the person requesting the ride
        seats: int
            Total number of seats requested by the rider
        selection_strategy: str
            Selection Strategy followed by the user
            If "MOST_VACANT" is passed -> The ride with minimum vacant
            seats is considered as evaluation criteria for most vacant
            For anything else, it is assumed that it is name of vehicle
        trips: List[Trip]
            Contains list of trip information
        max_trips: int
            Maximum number of trips the user is willing to take
        """
        queue = deque()
        queue.append([source, 0, list()])
        least_trips = float("inf")
        trip_paths_found = list()
        while len(queue):

            node, total_trips, current_path = queue.popleft()

            if node == destination:
                least_trips = total_trips
                trip_paths_found.append(current_path.copy())

                # if the selection strategy is not `MOST_VACANT`, then we assume that
                # we want to match with vehicle preference
                # And the first answer that we get is the correct answer itself
                if selection_strategy != SelectionStrategies.MOST_VACANT.name:
                    return current_path

            if total_trips < min(least_trips, max_trips):
                # Find next possible trips
                for next_trip in trips.get(node, []):
                    if (
                        next_trip.source == node
                        and next_trip.driver_name != user_name
                        and next_trip.available_seats >= seats
                        and next_trip.status == TripStatus.SCHEDULED.name
                    ):
                        if selection_strategy == SelectionStrategies.MOST_VACANT.name:
                            # Perform a shall copy to keep references of trip
                            # This is important as the reference is leveraged by updating
                            # the number of available seats
                            new_path = current_path.copy() + [next_trip]
                            queue.append(
                                [next_trip.destination, total_trips + 1, new_path]
                            )
                        else:
                            if next_trip.vehicle.name == selection_strategy:
                                # Perform a shall copy to keep references of trip
                                # This is important as the reference is leveraged when updating
                                # the number of available seats
                                new_path = current_path.copy() + [next_trip]
                                queue.append(
                                    [next_trip.destination, total_trips + 1, new_path]
                                )

        if len(trip_paths_found):
            # This condition is only executed if trip paths have been found
            # And the selection strategy is MOST_VACANT

            # Out of `len(trip_paths_found)` it tries to find the most optimum
            # path by finding the minimum vacancy in each trip, and then taking the one
            # with highest minimum vacancy
            best_trip_index = 0
            max_min_seats_available = 0
            for current_trip_index, current_trip_path in enumerate(trip_paths_found):
                current_min_seats_available = float("inf")
                for trip in current_trip_path:
                    current_min_seats_available = min(
                        trip.available_seats, current_min_seats_available
                    )
                if current_min_seats_available > max_min_seats_available:
                    max_min_seats_available = current_min_seats_available
                    best_trip_index = current_trip_index
            return trip_paths_found[best_trip_index]
        else:
            return []
