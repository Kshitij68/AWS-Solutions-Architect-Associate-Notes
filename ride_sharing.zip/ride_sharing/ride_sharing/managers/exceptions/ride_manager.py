class IncorrectSeatException(Exception):
    pass


class TripAlreadyPresentError(Exception):
    pass


class TripNotFoundError(Exception):
    pass


class SameSourceAndDestinationException(Exception):
    pass


class InvalidMaxTripsException(Exception):
    pass
