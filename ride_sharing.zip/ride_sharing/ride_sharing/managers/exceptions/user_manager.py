class InvalidAgeException(Exception):
    pass


class InvalidGenderException(Exception):
    pass


class UserAlreadyExistsException(Exception):
    pass


class UserNotFoundException(Exception):
    pass


class UserVehicleNotFoundException(Exception):
    pass


class UserVehicleAlreadyPresent(Exception):
    pass


class InValidUserVehicle(Exception):
    pass


class NoUserInfoToUpdateException(Exception):
    pass
