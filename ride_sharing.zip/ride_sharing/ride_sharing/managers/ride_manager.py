import collections
from typing import Dict, List

from ride_sharing.constants.constants import RideStatuses, TripStatus
from ride_sharing.managers.exceptions.ride_manager import (
    IncorrectSeatException,
    InvalidMaxTripsException,
    SameSourceAndDestinationException,
    TripAlreadyPresentError,
    TripNotFoundError,
)
from ride_sharing.managers.route_finding_manager import RouteFindingManager
from ride_sharing.managers.user_manager import UserManager
from ride_sharing.models.trip import Trip
from ride_sharing.models.user import User
from ride_sharing.models.vehicle import Vehicle


class RideManager:
    def __init__(
        self, user_manager: UserManager, route_finding_manager: RouteFindingManager
    ):
        self.__user_manager = user_manager
        self.__route_finding_manager = route_finding_manager
        self.__trips: Dict[str, List[Trip]] = collections.defaultdict(list)

    def add_offering(
        self,
        user_name: str,
        source: str,
        destination: str,
        available_seats: int,
        vehicle_name: str,
        vehicle_id: str,
    ) -> Dict:
        """
        Add a trip offering

        Parameters
        ----------
        user_name : str
            driver of the trip
        source: str
            Starting point of the trip
        destination: str
            Destination of the trip
        available_seats: int
            Total number of available seats in the trip
        vehicle_name: str
            Name of the vehicle
        vehicle_id: str
            ID of the vehicle
        """
        if source == destination:
            raise SameSourceAndDestinationException(
                "Please provide difference `source` and `destination`"
            )
        user: User = self.__user_manager.get_user(user_name)
        vehicle: Vehicle = self.__user_manager.get_user_vehicle(
            user_name, vehicle_name, vehicle_id
        )
        new_trip = Trip(
            driver=user,
            source=source,
            destination=destination,
            available_seats=available_seats,
            vehicle=vehicle,
        )
        for trips in self.__trips.values():
            for trip in trips:
                if trip == new_trip:
                    raise TripAlreadyPresentError(
                        "The trip is already registered in the system with that license plate"
                    )
        self.__trips[source].append(new_trip)
        return new_trip.to_json()

    def find_and_book_ride(
        self,
        user_name: str,
        source: str,
        destination: str,
        seats: int,
        selection_strategy: str,
        max_trips: int = 3,
    ) -> List[Dict]:
        """
        Finds the optimum ride to take in 1 trip

        TODO:
        # Currently the search space goes for all depths, but in real life it would make sense to
        # limit to certain depth as taking 10 rides does not make much sense.
        # This will also speed up the runtime as well as memory consumption

        Parameters
        ----------
        user_name : str
            Rider of the trip
        source: str
            Starting point of the trip
        destination: str
            Destination of the trip
        seats: int
            Total number of seats in the trip
        selection_strategy : str
            Selection Strategy for the trips.
            If "MOST_VACANT" is passed -> Trip with highest vacany is choosen
            If their are multiple possible trip paths, the path which has highest minimum vacancy is choosen
        max_trips: int
            Max trips the user is willing to take
        """
        if seats not in (1, 2):
            raise IncorrectSeatException("Please select exactly 1 or 2 seats")
        if source == destination:
            raise SameSourceAndDestinationException(
                "Please select different `source` and `destination`"
            )
        if max_trips < 0:
            raise InvalidMaxTripsException("Please set max_trips >= 0")
        user = self.__user_manager.get_user(user_name=user_name)
        final_trips: List[
            Trip
        ] = self.__route_finding_manager.find_ride_via_multiple_trips(
            user_name,
            source,
            destination,
            seats,
            selection_strategy,
            self.__trips,
            max_trips,
        )
        for trip in final_trips:
            trip.available_seats = trip.available_seats - seats
            trip.riders.append(user)
        return [trip.to_json() for trip in final_trips]

    def end_ride(
        self,
        user_name: str,
        source: str,
        destination: str,
        available_seats: int,
        vehicle_name: str,
        vehicle_id: str,
    ) -> Dict:
        """
        End the ride offered by the user

        Parameters
        ------------
        user_name : str
            driver of the trip
        source: str
            Starting point of the trip
        destination: str
            Destination of the trip
        available_seats: int
            Total number of available seats in the trip
        vehicle_name: str
            Name of the vehicle
        vehicle_id: str
            ID of the vehicle
        """
        vehicle: Vehicle = self.__user_manager.get_user_vehicle(
            user_name, vehicle_name, vehicle_id
        )
        user: User = self.__user_manager.get_user(user_name=user_name)
        cur_trip: Trip = Trip(
            driver=user,
            source=source,
            destination=destination,
            available_seats=available_seats,
            vehicle=vehicle,
        )
        for trip in self.__trips[source]:
            if cur_trip == trip:
                trip.status = TripStatus.ENDED.name
                return trip.to_json()
        raise TripNotFoundError("No such scheduled trip is found in the system")

    def print_ride_stats(self) -> RideStatuses:
        """
        Provide status of all users and the corresponding rides they have
         taken or offered
        """
        ride_stats: RideStatuses = {}
        for user_name in self.__user_manager.get_all_user_names():
            ride_stats[user_name] = {"Taken": 0, "Offered": 0}
        for trips in self.__trips.values():
            for trip in trips:
                if trip.status == TripStatus.ENDED.name:
                    ride_stats[trip.driver_name]["Offered"] += 1

                    riders = [rider.get_name() for rider in trip.riders]
                    for rider in riders:
                        ride_stats[rider]["Taken"] += 1

        return ride_stats
