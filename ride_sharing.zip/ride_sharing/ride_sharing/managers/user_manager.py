from typing import Dict, List

from ride_sharing.constants.constants import Gender, SelectionStrategies
from ride_sharing.managers.exceptions.user_manager import (
    InvalidAgeException,
    InvalidGenderException,
    InValidUserVehicle,
    NoUserInfoToUpdateException,
    UserAlreadyExistsException,
    UserNotFoundException,
    UserVehicleAlreadyPresent,
    UserVehicleNotFoundException,
)
from ride_sharing.models.user import User
from ride_sharing.models.vehicle import Vehicle


class UserManager:
    def __init__(self):
        self.__users: Dict[str] = {}

    def ___validate_user_info(
        self, user_name: str = None, age: int = None, gender: str = None
    ) -> None:
        if user_name is not None and user_name in self.__users:
            raise UserAlreadyExistsException("Username already exists!")
        if age is not None and age <= 0:
            raise InvalidAgeException("Please provide age greater than 0")
        if gender is not None and gender not in Gender.__members__:
            raise InvalidGenderException("Please provide `M` , `F` or `O` as gender")

    def add_user(self, user_name: str, age: int, gender: str) -> Dict:
        """
        Adds a user to the system

        Parameters
        ------------
        user_name : str
            Username of the vehicle owner
        age : int
            Age of the vehicle owner
        gender : str
            Gender of the vehicle owner
        """
        self.___validate_user_info(user_name=user_name, age=age, gender=gender)
        user = User(name=user_name, age=age, gender=gender)
        self.__users[user_name] = user
        return user.to_json()

    def update_user_info(self, user_name, age=None, gender=None) -> Dict:
        """
        Update user attributes like `age` and `gender`

        Note: `user_name` cannot be changed

        Parameters
        ------------
        user_name : str
            Username of the user
        age : int
            Updated age of the user
        gender : str
            Updated gender of the user
        """
        if user_name not in self.__users:
            raise UserNotFoundException("User not found!")
        if age is None and gender is None:
            raise NoUserInfoToUpdateException("No user information to update!")
        self.___validate_user_info(user_name=None, age=age, gender=gender)
        user: User = self.__users[user_name]
        if age is not None:
            user.set_age(age=age)
        if gender is not None:
            user.set_gender(gender=gender)
        return user.to_json()

    def add_user_vehicle(self, user_name: str, vehicle_name: str, vehicle_id: str):
        """
        Add vehicle for a given user

        Parameters
        ------------
        user_name : str
            Username of the vehicle owner
        vehicle_name: str
            Name of the vehicle
        vehicle_id : str
            Name Plate of the vehicle
        """
        if user_name not in self.__users:
            raise UserNotFoundException("User not found!")
        forbidden_vehicle_names = list(SelectionStrategies.__members__.keys())
        if vehicle_name in forbidden_vehicle_names:
            raise InValidUserVehicle(
                f"The following vehicle names are forbidden: {','.join(forbidden_vehicle_names)}"
            )
        current_vehicles = self.__users[user_name].vehicles
        new_vehicle = Vehicle(vehicle_name, vehicle_id)
        for current in current_vehicles:
            if current == new_vehicle:
                raise UserVehicleAlreadyPresent("Vehicle already present!")
        current_vehicles.append(Vehicle(vehicle_name, vehicle_id))
        self.__users[user_name].vehicle = current_vehicles

    def confirm_user(self, user_name) -> None:
        """
        Confirm if the user exists
        """
        if user_name not in self.__users:
            raise UserNotFoundException("User not found!")

    def get_user(self, user_name) -> User:
        """
        Get the user details from user_name

        Parameters
        ---------
        user_name : str
            User Name of the driver/rider
        """
        self.confirm_user(user_name)
        return self.__users[user_name]

    def get_user_vehicle(self, user_name: str, v_name: str, v_id: str) -> Vehicle:
        """
        Retrieves the vehicle for a given user

        Parameters
        user_name: str
            User Name of the vehicle owner
        v_name : str
            Name of the vehicle
        v_id : str
            Name Plate of the vehicle
        """
        vehicle = Vehicle(v_name, v_id)
        if user_name not in self.__users:
            raise UserNotFoundException("User not found!")
        for user_vehicle in self.__users[user_name].vehicles:
            if user_vehicle == vehicle:
                return vehicle
        raise UserVehicleNotFoundException("Vehicle not found!")

    def get_all_user_names(self) -> List[str]:
        """
        Gets list of all user names
        """
        return list(self.__users.keys())
