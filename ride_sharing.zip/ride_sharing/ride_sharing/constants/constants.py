from enum import Enum
from typing import TypedDict


class SelectionStrategies(Enum):
    MOST_VACANT = 1


class TripStatus(Enum):

    SCHEDULED = 1
    ENDED = 2


class Gender(Enum):

    M = 1
    F = 2
    O = 3


class RideStatus:
    Taken: int
    Offered: int


class RideStatuses(TypedDict):
    str: RideStatus
