# Run Example
NOTE: This has been tested on python 3.9.14 on Mac system only.
- Install python and pip in your system
- Perform Editable install of the software using `pip install -e . --index-url https://pypi.org/simple`
  - Driver script **may** work without this
- Install dependencies using
  - `pip install -r requirements-pinned.txt`
  - `pip install -r test-requirements-pinned.txt`
- Run the driver script using `python main.py`

# Run Unit Tests Locally
- Run editable version of the software `pip install -e . --index-url https://pypi.org/simple`
- Run editable version of the software `pip install -r test-requirements-pinned.txt`
- Run `python3 -m unittest tests/test_ride_sharing.py`
- 100% test coverage is present. To generate test coverage report run `pytest --cov-report term-missing --cov=ride_sharing tests/`

# Assumptions
- Unique users are identified via username
- Currently, data strucutures used are not the most efficient ones for booking and ending rides.
  I assumed that this was not part of evaluation criteria.
  For e.g. it should be possible to optimize the logic for adding/finding/ending trips
- Bonus question clarification:
  - When using MOST_VACANT strategy: We prioritize finding shortest path, followed by finding by most vacant trip
    vacany in a trip is defined by the minimum number of available seat in the trip
    Please refer to test `test_ride_finding_with_most_vacant_strategy_multiple_rides` which captures this scenario
  - `print_ride_status` requires calculating rides which are in state ENDED
     It is possible for ride to be from A -> B -> C -> D and only B and C are marked as "ended".
     In such a scenario, B and C rides are included in the calculation
- I assumed that the functionality must be implemented with same parameters as listed in the document.
  For e.g for `end_ride`, it would have maybe made more sense to only consider `user_name` and `vehicle_id`
  in the criteria
- Car Preference Strategy refers to a hard requirement that user will **only** travel in that car
- We do not allow vehicle names to be "MOST_VACANT", because otherwise we cannot differentiate at ride allocation
  whether we want to choose the most vacant strategy or name of vehicle is "MOST_VACANT"
- Unique ride offering is identified via (vehicle_ID, status)

# Additional Features added (beyond scope of assignment)
- Ability for the rider to limit total number of rides that the person is willing to take to go from source to destination
- Ability to update user information

# Potential Future Improvement in User Features
- User Ratings. Provide ratings for a given driver and filter on ratings (Low Complexity)
- Show all possible trip routes (in order of "priority") to rider and allow them to choose the trip (Medium Complexity)
- Ability for driver to Accept/Reject a request from a rider. (Medium Complexity)
- Consider date and time of journey in system (High Complexity)

# Potential Future Improvement in CodeBase
- Develop tooling for writing better tests by avoiding code duplication while ensuring test isolation
  - Trade off between CI/CD runtimes vs code duplication/length vs Code Maintainability/Readability
- Performance Benchmarks for BFS algorithm  
- Add Pre-Commit for Consistent Code Styles including strong checks using mypy
- Add loggers
- Changelog for better visibility in changes  
- Ensure CRUD
- Docstrings (including exceptions that can be thrown)
- Enforce Key-Value types in Dict