import pytest
from ride_sharing.managers.exceptions.ride_manager import TripNotFoundError
from ride_sharing.managers.ride_manager import RideManager
from ride_sharing.managers.route_finding_manager import RouteFindingManager
from ride_sharing.managers.user_manager import UserManager


def test_ride_ending():
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="B")
    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="A",
        vehicle_id="A",
    )
    result = ride_manager.end_ride(
        user_name="A",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="A",
        vehicle_id="A",
    )
    assert result == {
        "name": "A",
        "vehicle": {"name": "A", "id": "A"},
        "status": "ENDED",
    }

    with pytest.raises(
        TripNotFoundError, match="No such scheduled trip is found in the system"
    ):
        ride_manager.end_ride(
            user_name="A",
            source="A",
            destination="B",
            available_seats=1,
            vehicle_name="A",
            vehicle_id="B",
        )
