from typing import Dict, List, Union

import pytest
from ride_sharing.managers.exceptions.ride_manager import (
    IncorrectSeatException,
    InvalidMaxTripsException,
    SameSourceAndDestinationException,
)
from ride_sharing.managers.ride_manager import RideManager
from ride_sharing.managers.route_finding_manager import RouteFindingManager
from ride_sharing.managers.user_manager import UserManager


def _generate_user_info_and_vehicles(
    user_manager: UserManager,
    user_info_and_vehicle_map: Dict[
        str, Union[Dict[str, Union[int, str]], List[Dict[str, str]]]
    ],
):
    """
    Data Generator Helper functions

    TODO Crete testing utils folder and move it there.
    TODO - Create a generalized testing method for creating users,
    offering rides, creating offered trips etc..
    """
    for user_name in user_info_and_vehicle_map:
        user_age = user_info_and_vehicle_map[user_name].get("age")
        user_gender = user_info_and_vehicle_map[user_name].get("gender")
        user_manager.add_user(user_name=user_name, age=user_age, gender=user_gender)
        for index, _ in enumerate(user_info_and_vehicle_map.get(user_name, [])):
            vehicle_name = user_info_and_vehicle_map[user_name][index]["v_name"]
            vehicle_id = user_info_and_vehicle_map[user_name][index]["v_id"]
            user_manager.add_user_vehicle(
                user_name=user_name, vehicle_name=vehicle_name, vehicle_id=vehicle_id
            )


def test_rides_finding_most_vacant_strategy_single_ride():
    """
    We add 3 rides with different seat availability and test that
    vacancy criteria is correctly taken into account
    """
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user(user_name="B", age=10, gender="M")
    user_manager.add_user(user_name="C", age=10, gender="M")
    user_manager.add_user(user_name="D", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    user_manager.add_user_vehicle(user_name="B", vehicle_name="B", vehicle_id="B")
    user_manager.add_user_vehicle(user_name="C", vehicle_name="C", vehicle_id="C")

    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="A",
        vehicle_id="A",
    )
    ride_manager.add_offering(
        user_name="B",
        source="A",
        destination="B",
        available_seats=2,
        vehicle_name="B",
        vehicle_id="B",
    )
    ride_manager.add_offering(
        user_name="C",
        source="B",
        destination="C",
        available_seats=3,
        vehicle_name="C",
        vehicle_id="C",
    )

    result = ride_manager.find_and_book_ride(
        user_name="D",
        source="A",
        destination="B",
        seats=1,
        selection_strategy="MOST_VACANT",
    )
    assert result == [
        {"name": "B", "vehicle": {"name": "B", "id": "B"}, "status": "SCHEDULED"}
    ]

    # Now if we ask for a ride for 2 seats, we will not get any as only user `B`
    # was providing 2 seats in that route
    # and 1 seat is already occupied
    result = ride_manager.find_and_book_ride(
        user_name="D",
        source="A",
        destination="B",
        seats=2,
        selection_strategy="MOST_VACANT",
    )
    assert result == []


@pytest.mark.parametrize("max_trips", [3, 1])
def test_ride_finding_with_most_vacant_strategy_multiple_rides(max_trips):
    """
    We create 4 users
     - User A: Provides path from Source -> UA1 -> UA2 -> Destination. Each ride wil have 2 seats available
     - User B: Provides path from Source -> UB1 -> UB2 -> Destination. Each ride will have 3 seats available
     - User C: Provides path from Source -> UC1 -> UC2 -> UC3 -> UC4 -> Destination.
               Each ride will have 4 seats available.
     - User D: Requests ride from Source to Destination with most vacant strategy.
               We assert that User B trips are choosen as:
                - It has lesser number of trips between B and C
                - It has more seats than A

    """
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    for user in ["A", "B", "C", "D"]:
        user_manager.add_user(user_name=user, age=10, gender="M")
        if user != "D":
            user_manager.add_user_vehicle(
                user_name=user, vehicle_name=user, vehicle_id=user
            )

    # Offer rides for user A and B
    for user, available_seats in [
        ["A", 2],
        ["B", 3],
    ]:
        for source, destination in [
            ["S", "U" + user + "1"],
            ["U" + user + "1", "U" + user + "2"],
            ["U" + user + "2", "D"],
        ]:
            vehicle_info = user + "_" + source + "_" + destination
            user_manager.add_user_vehicle(
                user_name=user, vehicle_name=vehicle_info, vehicle_id=vehicle_info
            )
            ride_manager.add_offering(
                user_name=user,
                source=source,
                destination=destination,
                available_seats=available_seats,
                vehicle_name=vehicle_info,
                vehicle_id=vehicle_info,
            )

    # Offer rides for user C
    user = "C"
    for source, destination in [
        ["S", "U" + user + "1"],
        ["U" + user + "1", "U" + user + "2"],
        ["U" + user + "2", "U" + user + "3"],
        ["U" + user + "3", "D"],
    ]:
        vehicle_info = user + "_" + source + "_" + destination
        user_manager.add_user_vehicle(
            user_name=user, vehicle_name=vehicle_info, vehicle_id=vehicle_info
        )
        ride_manager.add_offering(
            user_name=user,
            source=source,
            destination=destination,
            available_seats=3,
            vehicle_name=vehicle_info,
            vehicle_id=vehicle_info,
        )

    result = ride_manager.find_and_book_ride(
        user_name="D",
        source="S",
        destination="D",
        seats=2,
        selection_strategy="MOST_VACANT",
        max_trips=max_trips,
    )
    if max_trips == 1:
        assert result == []
    else:
        assert result == [
            {
                "name": "B",
                "vehicle": {"name": "B_S_UB1", "id": "B_S_UB1"},
                "status": "SCHEDULED",
            },
            {
                "name": "B",
                "vehicle": {"name": "B_UB1_UB2", "id": "B_UB1_UB2"},
                "status": "SCHEDULED",
            },
            {
                "name": "B",
                "vehicle": {"name": "B_UB2_D", "id": "B_UB2_D"},
                "status": "SCHEDULED",
            },
        ]

    result = ride_manager.find_and_book_ride(
        user_name="D",
        source="S",
        destination="D",
        seats=2,
        selection_strategy="MOST_VACANT",
        max_trips=max_trips,
    )
    # Now if we request the ride again, we will end with rides offered by `A`, because the rides
    # offered by `B` have seating capacity remaining of only 1
    if max_trips == 1:
        assert result == []
    else:
        assert result == [
            {
                "name": "A",
                "vehicle": {"name": "A_S_UA1", "id": "A_S_UA1"},
                "status": "SCHEDULED",
            },
            {
                "name": "A",
                "vehicle": {"name": "A_UA1_UA2", "id": "A_UA1_UA2"},
                "status": "SCHEDULED",
            },
            {
                "name": "A",
                "vehicle": {"name": "A_UA2_D", "id": "A_UA2_D"},
                "status": "SCHEDULED",
            },
        ]


def test_ride_finding_with_car_preference_strategy():
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user(user_name="B", age=10, gender="M")
    user_manager.add_user(user_name="C", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    user_manager.add_user_vehicle(user_name="B", vehicle_name="B", vehicle_id="B")

    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="A",
        vehicle_id="A",
    )
    ride_manager.add_offering(
        user_name="B",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="B",
        vehicle_id="B",
    )

    result = ride_manager.find_and_book_ride(
        user_name="C", source="A", destination="B", seats=1, selection_strategy="B"
    )
    assert result == [
        {"name": "B", "vehicle": {"name": "B", "id": "B"}, "status": "SCHEDULED"}
    ]


@pytest.mark.parametrize("max_trips", [3, 1])
def test_ride_finding_with_most_car_preference_strategy_multiple_rides(max_trips):
    """
    We create 3 users
     - User A: Provides path from Source -> Destination. Each ride is via vehicle A
     - User B: Provides path from Source -> UB1 -> Destination. Each ride is via vehicle B
     - User C: Requests ride from Source to Destination with car preference `B`
               We assert that User B  trips are choosen as User A provides trip via vehicle `X

    """
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    for user in ["A", "B", "C"]:
        user_manager.add_user(user_name=user, age=10, gender="M")

    # Offer rides for user A
    user = "A"
    user_manager.add_user_vehicle(user_name=user, vehicle_name=user, vehicle_id=user)
    ride_manager.add_offering(
        user_name=user,
        source="S",
        destination="D",
        available_seats=10,
        vehicle_name=user,
        vehicle_id=user,
    )

    # Offer rides for user B
    user = "B"
    user_manager.add_user_vehicle(user_name=user, vehicle_name=user, vehicle_id="B1")
    user_manager.add_user_vehicle(user_name=user, vehicle_name=user, vehicle_id="B2")
    ride_manager.add_offering(
        user_name=user,
        source="S",
        destination="UB1",
        available_seats=10,
        vehicle_name=user,
        vehicle_id="B1",
    )
    ride_manager.add_offering(
        user_name=user,
        source="UB1",
        destination="D",
        available_seats=10,
        vehicle_name=user,
        vehicle_id="B2",
    )

    result = ride_manager.find_and_book_ride(
        user_name="C",
        source="S",
        destination="D",
        seats=1,
        selection_strategy="B",
        max_trips=max_trips,
    )
    if max_trips == 1:
        assert result == []
    else:
        assert result == [
            {"name": "B", "vehicle": {"name": "B", "id": "B1"}, "status": "SCHEDULED"},
            {"name": "B", "vehicle": {"name": "B", "id": "B2"}, "status": "SCHEDULED"},
        ]


def test_user_does_not_book_car_with_themselves():
    """
    This test tests that the user does not end up doing a booking for a car that they themselves offered
    """
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="A",
        vehicle_id="A",
    )

    result = ride_manager.find_and_book_ride(
        user_name="A", source="B", destination="A", seats=1, selection_strategy="A"
    )
    assert result == []


def test_user_does_not_book_ride_which_has_ended():
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user(user_name="B", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="A",
        vehicle_id="A",
    )
    ride_manager.end_ride(
        user_name="A",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="A",
        vehicle_id="A",
    )

    # Even though a ride exists, since it has already ended, it cannot be used
    result = ride_manager.find_and_book_ride(
        user_name="B", source="A", destination="B", seats=1, selection_strategy="A"
    )
    assert result == []
    result = ride_manager.print_ride_stats()
    assert result == {"A": {"Taken": 0, "Offered": 1}, "B": {"Taken": 0, "Offered": 0}}


def test_ride_finding_exceptions():
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user(user_name="B", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=1,
        vehicle_name="A",
        vehicle_id="A",
    )

    with pytest.raises(
        IncorrectSeatException, match="Please select exactly 1 or 2 seats"
    ):
        ride_manager.find_and_book_ride(
            user_name="B", source="A", destination="B", seats=10, selection_strategy="A"
        )

    with pytest.raises(
        SameSourceAndDestinationException,
        match="Please select different `source` and `destination`",
    ):
        ride_manager.find_and_book_ride(
            user_name="B", source="A", destination="A", seats=2, selection_strategy="A"
        )

    with pytest.raises(InvalidMaxTripsException, match="Please set max_trips >= 0"):
        ride_manager.find_and_book_ride(
            user_name="B",
            source="A",
            destination="B",
            seats=2,
            selection_strategy="A",
            max_trips=-1,
        )
