from ride_sharing.managers.ride_manager import RideManager
from ride_sharing.managers.route_finding_manager import RouteFindingManager
from ride_sharing.managers.user_manager import UserManager


def test_print_ride_status_user_who_did_not_offer_or_take_any_ride():
    """
    Tests that user who did not offer or take any ride is considered
    """
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=20, gender="M")
    result = ride_manager.print_ride_stats()
    assert result == {"A": {"Taken": 0, "Offered": 0}}


def test_print_ride_status_user_who_offered_ride_but_no_one_took():
    """
    Tests that user who offered ride but no one took them are also
    considered only when the ride state is ENDED
    """
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=20, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=2,
        vehicle_name="A",
        vehicle_id="A",
    )

    # Since the ride is still in scheduled state, it will not show up in result
    result = ride_manager.print_ride_stats()
    assert result == {"A": {"Taken": 0, "Offered": 0}}

    # Since the ride is now ended, it will show up in the result
    ride_manager.end_ride(
        user_name="A",
        source="A",
        destination="B",
        available_seats=2,
        vehicle_name="A",
        vehicle_id="A",
    )
    assert result == {"A": {"Taken": 0, "Offered": 0}}


def test_print_ride_status_when_user_offered_rides_and_someone_took():
    """
    Test that user who offered ride and was taken is considered only when the ride is in state ENDED
    """

    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=20, gender="M")
    user_manager.add_user(user_name="B", age=20, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=2,
        vehicle_name="A",
        vehicle_id="A",
    )

    ride_manager.find_and_book_ride(
        user_name="B", source="A", destination="B", seats=2, selection_strategy="A"
    )
    result = ride_manager.print_ride_stats()
    assert result == {"A": {"Taken": 0, "Offered": 0}, "B": {"Taken": 0, "Offered": 0}}
    ride_manager.end_ride(
        user_name="A",
        source="A",
        destination="B",
        available_seats=2,
        vehicle_name="A",
        vehicle_id="A",
    )
    result = ride_manager.print_ride_stats()
    assert result == {"A": {"Taken": 0, "Offered": 1}, "B": {"Taken": 1, "Offered": 0}}
