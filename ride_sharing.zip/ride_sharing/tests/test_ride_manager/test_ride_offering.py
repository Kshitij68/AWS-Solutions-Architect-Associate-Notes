import pytest
from ride_sharing.managers.exceptions.ride_manager import (
    SameSourceAndDestinationException,
    TripAlreadyPresentError,
)
from ride_sharing.managers.ride_manager import RideManager
from ride_sharing.managers.route_finding_manager import RouteFindingManager
from ride_sharing.managers.user_manager import UserManager


def test_ride_offering():
    """
    Tests that the rides offered are added with correct status
    Also test the exception is raised properly when duplicates are added
    """
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )

    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    result = ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=2,
        vehicle_name="A",
        vehicle_id="A",
    )
    assert result == {
        "name": "A",
        "vehicle": {"name": "A", "id": "A"},
        "status": "SCHEDULED",
    }
    assert len(ride_manager._RideManager__trips) == 1
    assert result == {
        "name": "A",
        "vehicle": {"name": "A", "id": "A"},
        "status": "SCHEDULED",
    }


def test_can_offer_ride_again_after_ending():
    """
    This asserts that we can offer the ride after it has ended
    """
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    offering = {
        "user_name": "A",
        "source": "A",
        "destination": "B",
        "available_seats": 2,
        "vehicle_name": "A",
        "vehicle_id": "A",
    }
    ride_manager.add_offering(**offering)
    ride_manager.end_ride(**offering)
    ride_manager.add_offering(**offering)


def test_ride_offering_exceptions():

    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    ride_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    ride_manager.add_offering(
        user_name="A",
        source="A",
        destination="B",
        available_seats=2,
        vehicle_name="A",
        vehicle_id="A",
    )

    # We confirm that trip duplication is checked only via vehicle ID and nothing else
    with pytest.raises(
        TripAlreadyPresentError,
        match="The trip is already registered in the system with that license plate",
    ):
        ride_manager.add_offering(
            user_name="A",
            source="B",
            destination="C",
            available_seats=2,
            vehicle_name="A",
            vehicle_id="A",
        )

    with pytest.raises(
        SameSourceAndDestinationException,
        match="Please provide difference `source` and `destination`",
    ):
        ride_manager.add_offering(
            user_name="A",
            source="C",
            destination="C",
            available_seats=2,
            vehicle_name="A",
            vehicle_id="A",
        )
