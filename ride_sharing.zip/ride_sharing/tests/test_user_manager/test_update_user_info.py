import pytest
from ride_sharing.managers.exceptions.user_manager import (
    InvalidAgeException,
    InvalidGenderException,
    NoUserInfoToUpdateException,
    UserNotFoundException,
)
from ride_sharing.managers.user_manager import UserManager


def test_update_user_info():
    """
    Test the functionality to add user
    """
    user_manager = UserManager()
    user_manager.add_user(user_name="A", age=10, gender="M")
    result = user_manager.update_user_info(user_name="A", age=20)
    assert result == {"name": "A", "age": 20, "gender": "M", "vehicle": []}

    result = user_manager.update_user_info(user_name="A", gender="F")
    assert result == {"name": "A", "age": 20, "gender": "F", "vehicle": []}

    with pytest.raises(UserNotFoundException, match="User not found!"):
        user_manager.update_user_info(user_name="B", age=20)

    with pytest.raises(
        NoUserInfoToUpdateException, match="No user information to update!"
    ):
        user_manager.update_user_info(user_name="A")

    with pytest.raises(InvalidAgeException, match="Please provide age greater than 0"):
        user_manager.update_user_info(user_name="A", age=-10)

    with pytest.raises(
        InvalidGenderException, match="Please provide `M` , `F` or `O` as gender"
    ):
        user_manager.update_user_info(user_name="A", gender="Random")
