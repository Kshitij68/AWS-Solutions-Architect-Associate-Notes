import pytest
from ride_sharing.managers.exceptions.user_manager import UserNotFoundException
from ride_sharing.managers.user_manager import UserManager


def test_confirm_user():
    """
    Test all the functionality to confirm user
    """
    user_manager = UserManager()
    user_manager.add_user(user_name="A", age=10, gender="M")

    with pytest.raises(UserNotFoundException, match="User not found!"):
        user_manager.confirm_user(user_name="B")
