import pytest
from ride_sharing.managers.exceptions.user_manager import (
    UserNotFoundException,
    UserVehicleNotFoundException,
)
from ride_sharing.managers.user_manager import UserManager
from ride_sharing.models.vehicle import Vehicle


def test_get_user_vehicle():
    """
    Test the functionality to confirm user
    """
    user_manager = UserManager()
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    result = user_manager.get_user_vehicle(user_name="A", v_name="A", v_id="A")
    assert isinstance(result, Vehicle)
    assert result.to_json() == {"name": "A", "id": "A"}


def test_get_user_vehicle_errors():
    user_manager = UserManager()
    user_manager.add_user(user_name="A", age=10, gender="M")
    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")
    with pytest.raises(UserNotFoundException, match="User not found!"):
        user_manager.get_user_vehicle(user_name="B", v_name="A", v_id="A")
    with pytest.raises(UserVehicleNotFoundException, match="Vehicle not found!"):
        user_manager.get_user_vehicle(user_name="A", v_name="A", v_id="B")
