import pytest
from ride_sharing.managers.exceptions.user_manager import (
    InvalidAgeException,
    InvalidGenderException,
    UserAlreadyExistsException,
)
from ride_sharing.managers.user_manager import UserManager


def test_add_users():
    """
    Test the functionality to add user
    """
    user_manager = UserManager()
    user_manager.add_user(user_name="A", age=10, gender="M")

    # Re-adding the same user even with different age and gender does not work
    with pytest.raises(UserAlreadyExistsException, match="Username already exists!"):
        user_manager.add_user(user_name="A", age=20, gender="F")

    # Passing 0 or -ve age does not work
    with pytest.raises(InvalidAgeException, match="Please provide age greater than 0"):
        user_manager.add_user(user_name="B", age=-10, gender="M")
    with pytest.raises(InvalidAgeException, match="Please provide age greater than 0"):
        user_manager.add_user(user_name="B", age=0, gender="M")

    # Only 3 genders are supported
    user_manager.add_user(user_name="B", age=10, gender="F")
    user_manager.add_user(user_name="C", age=10, gender="O")
    with pytest.raises(
        InvalidGenderException, match="Please provide `M` , `F` or `O` as gender"
    ):
        user_manager.add_user(user_name="D", age=10, gender="random")
