import pytest
from ride_sharing.constants.constants import SelectionStrategies
from ride_sharing.managers.exceptions.user_manager import (
    InValidUserVehicle,
    UserNotFoundException,
    UserVehicleAlreadyPresent,
)
from ride_sharing.managers.user_manager import UserManager


def test_add_user_vehicle():
    user_manager = UserManager()
    user_manager.add_user(user_name="A", age=10, gender="M")

    # Cannot add vehicle to user who is not registered
    with pytest.raises(UserNotFoundException, match="User not found!"):
        user_manager.add_user_vehicle(user_name="B", vehicle_name="B", vehicle_id="B")

    user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")

    with pytest.raises(UserVehicleAlreadyPresent, match="Vehicle already present!"):
        user_manager.add_user_vehicle(user_name="A", vehicle_name="A", vehicle_id="A")

    for key in SelectionStrategies.__members__.keys():
        with pytest.raises(
            InValidUserVehicle,
            match="The following vehicle names are forbidden: MOST_VACANT",
        ):
            user_manager.add_user_vehicle(
                user_name="A", vehicle_name=key, vehicle_id="C"
            )
