import time

from ride_sharing.managers.ride_manager import RideManager
from ride_sharing.managers.route_finding_manager import RouteFindingManager
from ride_sharing.managers.user_manager import UserManager

if __name__ == "__main__":

    print("Starting to run the demo script now")
    time.sleep(1)

    # User registration
    user_manager = UserManager()
    route_finding_manager = RouteFindingManager()
    rider_manager = RideManager(
        user_manager=user_manager, route_finding_manager=route_finding_manager
    )

    # Add users
    print("Adding users")
    time.sleep(1)
    user_manager.add_user(user_name="Rohan", age=36, gender="M")
    user_manager.add_user(user_name="Shashank", age=29, gender="M")
    user_manager.add_user(user_name="Nandini", age=29, gender="F")
    user_manager.add_user(user_name="Shipra", age=27, gender="F")
    user_manager.add_user(user_name="Gaurav", age=29, gender="M")
    user_manager.add_user(user_name="Rahul", age=35, gender="M")

    # Add user vehicles
    print("Adding vehicles")
    time.sleep(1)
    user_manager.add_user_vehicle(
        user_name="Rohan", vehicle_name="Swift", vehicle_id="KA-01-12345"
    )
    user_manager.add_user_vehicle(
        user_name="Shashank", vehicle_name="Baleno", vehicle_id="TS-05-62395"
    )
    user_manager.add_user_vehicle(
        user_name="Shipra", vehicle_name="Polo", vehicle_id="KA-05-41491"
    )
    user_manager.add_user_vehicle(
        user_name="Shipra", vehicle_name="Activa", vehicle_id="KA-12-12332"
    )
    user_manager.add_user_vehicle(
        user_name="Rahul", vehicle_name="XUV", vehicle_id="KA-05-1234"
    )

    # Add rides that users are offering
    print("Adding rides that users are offering")
    time.sleep(1)
    rider_manager.add_offering(
        user_name="Rohan",
        source="Hyderabad",
        destination="Bangalore",
        vehicle_name="Swift",
        available_seats=1,
        vehicle_id="KA-01-12345",
    )
    rider_manager.add_offering(
        user_name="Shipra",
        source="Bangalore",
        destination="Mysore",
        vehicle_name="Activa",
        available_seats=1,
        vehicle_id="KA-12-12332",
    )
    rider_manager.add_offering(
        user_name="Shipra",
        source="Bangalore",
        destination="Mysore",
        vehicle_name="Polo",
        available_seats=2,
        vehicle_id="KA-05-41491",
    )
    rider_manager.add_offering(
        user_name="Shashank",
        source="Hyderabad",
        destination="Bangalore",
        vehicle_name="Baleno",
        available_seats=2,
        vehicle_id="TS-05-62395",
    )
    rider_manager.add_offering(
        user_name="Rahul",
        source="Hyderabad",
        destination="Bangalore",
        vehicle_name="XUV",
        available_seats=5,
        vehicle_id="KA-05-1234",
    )
    try:
        rider_manager.add_offering(
            user_name="Rohan",
            source="Bangalore",
            destination="Pune",
            vehicle_name="Swift",
            available_seats=1,
            vehicle_id="KA-01-12345",
        )
    except Exception as e:
        print(str(e))

    # Finding rides
    print("Finding rides for users")
    time.sleep(1)
    result = rider_manager.find_and_book_ride(
        user_name="Nandini",
        source="Bangalore",
        destination="Mysore",
        seats=1,
        selection_strategy="MOST_VACANT",
    )
    assert result == [
        {
            "name": "Shipra",
            "vehicle": {"name": "Polo", "id": "KA-05-41491"},
            "status": "SCHEDULED",
        }
    ]

    result = rider_manager.find_and_book_ride(
        user_name="Gaurav",
        source="Bangalore",
        destination="Mysore",
        seats=1,
        selection_strategy="Activa",
    )
    assert result == [
        {
            "name": "Shipra",
            "vehicle": {"name": "Activa", "id": "KA-12-12332"},
            "status": "SCHEDULED",
        }
    ]

    # Empty result means no rides found
    result = rider_manager.find_and_book_ride(
        user_name="Shashank",
        source="Mumbai",
        destination="Bangalore",
        seats=1,
        selection_strategy="MOST_VACANT",
    )
    assert result == []

    result = rider_manager.find_and_book_ride(
        user_name="Rohan",
        source="Hyderabad",
        destination="Bangalore",
        seats=1,
        selection_strategy="Baleno",
    )
    assert result == [
        {
            "name": "Shashank",
            "vehicle": {"name": "Baleno", "id": "TS-05-62395"},
            "status": "SCHEDULED",
        }
    ]

    result = rider_manager.find_and_book_ride(
        user_name="Shashank",
        source="Hyderabad",
        destination="Bangalore",
        seats=1,
        selection_strategy="Polo",
    )
    assert result == []

    print("Ending rides")
    time.sleep(1)
    result = rider_manager.end_ride(
        user_name="Rohan",
        source="Hyderabad",
        destination="Bangalore",
        vehicle_name="Swift",
        available_seats=1,
        vehicle_id="KA-01-12345",
    )
    assert result == {
        "name": "Rohan",
        "vehicle": {"name": "Swift", "id": "KA-01-12345"},
        "status": "ENDED",
    }
    result = rider_manager.end_ride(
        user_name="Shipra",
        source="Bangalore",
        destination="Mysore",
        vehicle_name="Activa",
        available_seats=1,
        vehicle_id="KA-12-12332",
    )
    assert result == {
        "name": "Shipra",
        "vehicle": {"name": "Activa", "id": "KA-12-12332"},
        "status": "ENDED",
    }
    result = rider_manager.end_ride(
        user_name="Shipra",
        source="Bangalore",
        destination="Mysore",
        vehicle_name="Polo",
        available_seats=2,
        vehicle_id="KA-05-41491",
    )
    assert result == {
        "name": "Shipra",
        "vehicle": {"name": "Polo", "id": "KA-05-41491"},
        "status": "ENDED",
    }
    result = rider_manager.end_ride(
        user_name="Shashank",
        source="Hyderabad",
        destination="Bangalore",
        vehicle_name="Baleno",
        available_seats=2,
        vehicle_id="TS-05-62395",
    )
    assert result == {
        "name": "Shashank",
        "vehicle": {"name": "Baleno", "id": "TS-05-62395"},
        "status": "ENDED",
    }

    print("Providing ride status")
    result = rider_manager.print_ride_stats()
    print(result)
    expected_result = {
        "Rohan": {"Taken": 1, "Offered": 1},
        "Shipra": {"Taken": 0, "Offered": 2},
        "Gaurav": {"Taken": 1, "Offered": 0},
        "Nandini": {"Taken": 1, "Offered": 0},
        "Shashank": {"Taken": 0, "Offered": 1},
        "Rahul": {"Taken": 0, "Offered": 0},
    }
    assert expected_result == result

    print("Starting to run unit tests now")
    import os

    os.system("pytest --cov-report term-missing --cov=ride_sharing tests/")
